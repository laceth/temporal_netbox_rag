export default function Page(){return <main>NetOps UI</main>}
